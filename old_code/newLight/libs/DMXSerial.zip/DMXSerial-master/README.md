DmxSerial
==========

An Arduino library for sending and receiving DMX packets.
You can implement DMX devices and DMX controller with this library.

You can find more detail on this library at http://www.mathertel.de/Arduino/DMXSerial.aspx.

A suitable hardware is the Arduino platform plus a shield for the DMX
physical protocol implementation.
You can find such a shield at: http://www.mathertel.de/Arduino/DMXShield.aspx.

